package com.hexaware.project.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class PaymentHistory {
	@Id
	private Long paymentId;
	private Long bookingId;
	private float amountPaid;
	private LocalDate paymentDate;
	private Long userId;

	public PaymentHistory() {
		// TODO Auto-generated constructor stub
	}

	public PaymentHistory(Long paymentId, Long bookingId, float amountPaid, LocalDate paymentDate, Long userId) {
		super();
		this.paymentId = paymentId;
		this.bookingId = bookingId;
		this.amountPaid = amountPaid;
		this.paymentDate = paymentDate;
		this.userId = userId;
	}

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public float getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(float amountPaid) {
		this.amountPaid = amountPaid;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "PaymentHistory [paymentId=" + paymentId + ", bookingId=" + bookingId + ", amountPaid=" + amountPaid
				+ ", paymentDate=" + paymentDate + ", userId=" + userId + "]";
	}

	
	

}
