package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.PaymentHistoryDTO;
import com.hexaware.project.entity.Bookings;
import com.hexaware.project.entity.PaymentHistory;
import com.hexaware.project.repository.IPaymentHistoryRepository;

@Service
public class PaymentHistoryService implements IPaymentHistory {

	@Autowired
	IPaymentHistoryRepository repository;
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public PaymentHistory createPaymentHistory(PaymentHistoryDTO paymenthistorydto) {
		PaymentHistory paymenthistory =new PaymentHistory();
		paymenthistory.setPaymentId(paymenthistorydto.getPaymentId());
		paymenthistory.setBookingId(paymenthistorydto.getBookingId());
		paymenthistory.setAmountPaid(paymenthistorydto.getAmountPaid());
		paymenthistory.setPaymentDate(paymenthistorydto.getPaymentDate());
		paymenthistory.setUserId(paymenthistorydto.getUserId());
		return repository.save(paymenthistory);
	}

	@Override
	public PaymentHistory updatePaymentHistory(PaymentHistoryDTO paymenthistorydto,Long paymentId) {
		PaymentHistory paymenthistory =new PaymentHistory();
		paymenthistory.setPaymentId(paymenthistorydto.getPaymentId());
		paymenthistory.setBookingId(paymenthistorydto.getBookingId());
		paymenthistory.setAmountPaid(paymenthistorydto.getAmountPaid());
		paymenthistory.setPaymentDate(paymenthistorydto.getPaymentDate());
		paymenthistory.setUserId(paymenthistorydto.getUserId());
		return repository.save(paymenthistory);
	}

	@Override
	public void deletePaymentHistory(Long paymentId) {
		repository.deleteById(paymentId);
		
	}

	@Override
	public PaymentHistoryDTO getPaymentHistoryById(Long paymentId) {
		PaymentHistory paymenthistory=repository.findById(paymentId).orElse(new PaymentHistory());
		return new PaymentHistoryDTO(paymenthistory.getPaymentId(),paymenthistory.getBookingId(),paymenthistory.getAmountPaid(),paymenthistory.getPaymentDate(),paymenthistory.getUserId());
	}

	@Override
	public List<PaymentHistory> getAllPaymentHistory() {
		// TODO Auto-generated method stub
		return repository.findAll(Sort.by("bookingId"));
	}
	
}
