package com.hexaware.project.restcontroller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.UserCustomersDTO;
import com.hexaware.project.entity.UserCustomers;
import com.hexaware.project.exceptions.UserCustomerNotFountException;
import com.hexaware.project.service.IUserCustomers;

@RestController
@RequestMapping("/api/usercustomers")
class UserCustomerRestController {
	@Autowired
	IUserCustomers  usercustomer;
	
	@PostMapping("/create")
	public  UserCustomers  createUser(@RequestBody UserCustomersDTO usercustomerdto) {
		return  usercustomer.createUser(usercustomerdto);
	}
	
	@PutMapping("/update/{userId}")
	public  UserCustomers  updateUser(@RequestBody UserCustomersDTO usercustomerdto,@PathVariable Long userId) {
		return  usercustomer.updateUser(usercustomerdto,userId);
	}
	@DeleteMapping("/delete/{userId}")
	public void deleteUser(@PathVariable Long userId)
	{
		usercustomer.deleteUser(userId);
	
	}
	@GetMapping("/getById/{userId}")
	public  UserCustomersDTO getUserById(@PathVariable Long userId)throws  UserCustomerNotFountException{
		
		
		if(userId==0) {
			throw new  UserCustomerNotFountException(HttpStatus.BAD_REQUEST,"User not found"+userId);
		}
		return  usercustomer.getUserById(userId);	
		
	}
	@GetMapping("/getall")
	public List< UserCustomers >getAllUserCustomers(){
		
		return  usercustomer.getAllUserCustomers();	
		
	}

}
