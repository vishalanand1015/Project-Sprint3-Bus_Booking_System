package com.hexaware.project.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.TripsDTO;
import com.hexaware.project.entity.Trips;
import com.hexaware.project.service.ITrips;

@RestController
@RequestMapping("/api/trips")
public class TripsRestController {


	@Autowired
	ITrips trips;
	@PostMapping("/create")
	public Trips  createTrips(@RequestBody TripsDTO tripdto) {
		return trips.createTrips(tripdto);
	}
	@PutMapping("/update/{bookingId}")
	public Trips  updateTrips(@RequestBody TripsDTO tripdto,@PathVariable Long tripId) {
		return trips.updateTrips(tripdto,tripId);
	}
	@DeleteMapping("/delete/{adminId}")
	public void deleteTrips(@PathVariable Long tripId)
	{
		trips.deleteTrips(tripId);
		
	}
	@GetMapping("/getById/{adminId}")
	public TripsDTO getTripsById(@PathVariable Long tripId) {
		
		return trips.getTripsById(tripId);	
		
	}
	@GetMapping("/getall")
	public List<Trips > getAllTrips(){
		
		return trips.getAllTrips();
	
	}
}
