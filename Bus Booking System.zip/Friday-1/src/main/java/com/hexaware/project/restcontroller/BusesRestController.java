package com.hexaware.project.restcontroller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.BusesDTO;
import com.hexaware.project.entity.Buses;
import com.hexaware.project.exceptions.BusesNotFoundException;
import com.hexaware.project.service.IBuses;
@RestController
@RequestMapping("/api/buses")
public class BusesRestController {
	@Autowired
	IBuses buses;
	
	@PostMapping("/create")
	public Buses createBuses(@RequestBody BusesDTO busdto) {
		return buses.createBuses(busdto);
	}
	
	@PutMapping("/update/{bookingId}")
	public Buses updateBuses(@RequestBody BusesDTO busdto,@PathVariable Long busId) {
		return  buses.updateBuses(busdto,busId);
	}
	@DeleteMapping("/delete/{bookingId}")
	public void deleteBuses(@PathVariable Long busId)
	{
		buses.deleteBuses(busId);
	
	}
	@GetMapping("/getById/{busId}")
	public BusesDTO getBusById(@PathVariable Long busId)throws BusesNotFoundException{
		
		
		if(busId==0) {
			throw new BusesNotFoundException(HttpStatus.BAD_REQUEST,"bus not found"+busId);
		}
		return  buses.getBusById(busId);	
		
	}
	@GetMapping("/getAll")
	public List<Buses> getAllBuses(){
		
		return  buses.getAllBuses();	
		
	}

	@GetMapping(value="/getBusRouteById/{busId}")
	public BusesDTO getBybusId(@PathVariable Long busId){
		
		
		
		return  buses.getBybusId(busId);	
		
	}
	

}
