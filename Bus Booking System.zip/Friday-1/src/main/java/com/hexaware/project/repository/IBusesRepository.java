package com.hexaware.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.project.dto.BusesDTO;
import com.hexaware.project.entity.Buses;
@Repository
public interface IBusesRepository extends JpaRepository<Buses,Long >{

	public BusesDTO getBybusId(Long busId);
}
