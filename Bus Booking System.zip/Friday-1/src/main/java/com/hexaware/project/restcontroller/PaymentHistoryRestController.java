package com.hexaware.project.restcontroller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.PaymentHistoryDTO;
import com.hexaware.project.entity.PaymentHistory;
import com.hexaware.project.service.IPaymentHistory;

@RestController
@RequestMapping("/api/paymenthistory")
public class PaymentHistoryRestController {

	IPaymentHistory paymenthistory;

	@PostMapping("/create")
	public PaymentHistory createPaymentHistory(@RequestBody PaymentHistoryDTO paymenthistorydto) {
		return paymenthistory.createPaymentHistory(paymenthistorydto);
	}
	@PutMapping("/update/{paymentId}")
	public PaymentHistory updatePaymentHistory(@RequestBody PaymentHistoryDTO paymenthistorydto,@PathVariable Long paymentId) {
		return paymenthistory.updatePaymentHistory(paymenthistorydto,paymentId);
	}
	@DeleteMapping("/delete/{paymentId}")
	public void deletePaymentHistory(@PathVariable Long paymentId)
	{
		paymenthistory.deletePaymentHistory(paymentId);
		
	}
	@GetMapping("/getById/{paymentId}")
	public PaymentHistoryDTO getPaymentHistoryById(@PathVariable Long paymentId) {
		
		return paymenthistory.getPaymentHistoryById(paymentId);	
		
	}
	@GetMapping("/getall")
	public List<PaymentHistory> getAllPaymentHistory(){
		
		return paymenthistory.getAllPaymentHistory();
	
	}
	
}
