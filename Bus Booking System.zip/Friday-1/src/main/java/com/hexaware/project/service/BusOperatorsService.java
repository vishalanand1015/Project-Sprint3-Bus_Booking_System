package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.BusOperatorsDTO;
import com.hexaware.project.entity.Bookings;
import com.hexaware.project.entity.BusOperators;
import com.hexaware.project.repository.IBusOperatorsRepository;


@Service
public class BusOperatorsService implements IBusOperators {
	
	@Autowired
	IBusOperatorsRepository repository;
	@Autowired
	RestTemplate restTemplate;

	@Override
	public BusOperators createBusOperators(BusOperatorsDTO busoperatorsdto) {
		BusOperators busoperator=new BusOperators();
		busoperator.setOperatorId(busoperatorsdto.getOperatorId());
		busoperator.setOperatorName(busoperatorsdto.getOperatorName());
		busoperator.setContactPhone(busoperatorsdto.getContactPhone());
		busoperator.setRating(busoperatorsdto.getRating());
		busoperator.setUser_Id(busoperatorsdto.getUser_Id());
		return repository.save(busoperator);
	}

	@Override
	public BusOperators updateBusOperators(BusOperatorsDTO busoperatorsdto,Long operatorId) {
		BusOperators busoperator=new BusOperators();
		busoperator.setOperatorId(busoperatorsdto.getOperatorId());
		busoperator.setOperatorName(busoperatorsdto.getOperatorName());
		busoperator.setContactPhone(busoperatorsdto.getContactPhone());
		busoperator.setRating(busoperatorsdto.getRating());
		busoperator.setUser_Id(busoperatorsdto.getUser_Id());
		return repository.save(busoperator);
	}

	@Override
	public void  deleteBusOperators(Long operatorId) {
		repository.deleteById(operatorId);
	}

	@Override
	public BusOperatorsDTO getBusOperatorsById(Long OperatorId) {
		
		BusOperators busoperators=repository.findById(OperatorId).orElse(new BusOperators());
		return new BusOperatorsDTO(busoperators.getOperatorId(),busoperators.getOperatorName(),busoperators.getContactPhone(),busoperators.getRating(),busoperators.getUser_Id());
	}

	@Override
	public List<BusOperators> getAllBusOperators() {
		// TODO Auto-generated method stub
		return repository.findAll(Sort.by("operatorName"));
	}

}
	
