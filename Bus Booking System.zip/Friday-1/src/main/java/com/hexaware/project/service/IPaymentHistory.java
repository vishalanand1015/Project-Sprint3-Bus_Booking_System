package com.hexaware.project.service;

import java.util.List;

import com.hexaware.project.dto.PaymentHistoryDTO;
import com.hexaware.project.entity.PaymentHistory;



public interface IPaymentHistory {
	public PaymentHistory createPaymentHistory(PaymentHistoryDTO paymenthistorydto);
	public  PaymentHistory  updatePaymentHistory(PaymentHistoryDTO  paymenthistorydto,Long paymentHistoryId);
	public void  deletePaymentHistory(Long paymentId);
	public PaymentHistoryDTO getPaymentHistoryById(Long paymentId);
	public List<PaymentHistory>getAllPaymentHistory();

}
	