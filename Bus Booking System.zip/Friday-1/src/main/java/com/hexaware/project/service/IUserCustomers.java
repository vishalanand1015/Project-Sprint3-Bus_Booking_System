package com.hexaware.project.service;

import java.util.List;

import com.hexaware.project.dto.UserCustomersDTO;
import com.hexaware.project.entity.UserCustomers;



public interface IUserCustomers {

	public UserCustomers createUser(UserCustomersDTO usercustomerdto);
	public UserCustomers updateUser(UserCustomersDTO usercustomerdto,Long userId);
	public void  deleteUser(Long userId);
	public UserCustomersDTO getUserById(Long userId);
	public List<UserCustomers>getAllUserCustomers();
	
	

}
