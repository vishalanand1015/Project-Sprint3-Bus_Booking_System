package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.TripsDTO;
import com.hexaware.project.entity.Trips;
import com.hexaware.project.repository.ITripsRepository;



@Service
public class TripsService implements ITrips {
	@Autowired
	ITripsRepository repository;

	@Autowired
	RestTemplate restTemplate;
	@Override
	public Trips createTrips(TripsDTO tripsdto) {
		Trips trips=new Trips();
		trips.setTripId(tripsdto.getBusId());
		trips.setBusId(tripsdto.getBusId());
		trips.setOperatorId(tripsdto.getOperatorId());
		trips.setSourceCity(tripsdto.getSourceCity());
		trips.setDistanceInKms(tripsdto.getDistanceInKms());
		trips.setDurationInHours(tripsdto.getDurationInHours());
		trips.setDepartureTime(tripsdto.getDepartureTime());
		trips.setFare(tripsdto.getFare());
		
		return repository.save(trips);
		
	}

	@Override
	public Trips updateTrips(TripsDTO tripsdto,Long tripId) {
		Trips trips=new Trips();
		trips.setTripId(tripsdto.getTripId());
		trips.setBusId(tripsdto.getBusId());
		trips.setOperatorId(tripsdto.getOperatorId());
		trips.setSourceCity(tripsdto.getSourceCity());
		trips.setDistanceInKms(tripsdto.getDistanceInKms());
		trips.setDurationInHours(tripsdto.getDurationInHours());
		trips.setDepartureTime(tripsdto.getDepartureTime());
		trips.setFare(tripsdto.getFare());
		
		return repository.save(trips);
	}

	@Override
	public void deleteTrips(Long tripId) {
		repository.deleteById(tripId);
	}

	@Override
	public TripsDTO getTripsById(Long tripId) {
		Trips trips=repository.findById(tripId).orElse(new Trips());
		return new TripsDTO(trips.getTripId(),trips.getBusId(),trips.getOperatorId(),trips.getSourceCity(),trips.getDestinationCity(),trips.getDistanceInKms(),trips.getDurationInHours(),trips.getDepartureTime(),trips.getFare());
	}

	@Override
	public List<Trips> getAllTrips() {
		// TODO Auto-generated method stub
		return repository.findAll(Sort.by("tripId"));
	}
	
}
