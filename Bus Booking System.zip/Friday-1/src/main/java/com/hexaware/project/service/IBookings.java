package com.hexaware.project.service;

import java.util.List;

import com.hexaware.project.dto.BookingsDTO;
import com.hexaware.project.entity.Bookings;



public interface IBookings {
	
	public Bookings createBookings(BookingsDTO bookingsdto);
	public Bookings updateBookings(BookingsDTO bookingsdto,Long bookingId);
	public void  deleteBookings(Long bookingId);
	public BookingsDTO getBookingsById(Long bookingId);
	public List<Bookings>getAllBookings();

}
