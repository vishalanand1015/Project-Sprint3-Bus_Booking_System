package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.AdminDTO;
import com.hexaware.project.entity.Admin;
import com.hexaware.project.repository.IAdminRepository;


@Service
public class AdminService implements IAdmin {
	@Autowired
	IAdminRepository repository;
	@Autowired
	RestTemplate restTemplate;

	@Override
	public Admin createAdmin(AdminDTO admindto) {
		
		Admin admin=new Admin();
		admin.setAdminId(admindto.getAdminId());
		admin.setFirstName(admindto.getFirstName());
		admin.setLastName(admindto.getLastName());
		admin.setEmail(admindto.getEmail());
		admin.setPassword(admindto.getPassword());
		admin.setPhoneNumber(admindto.getPhoneNumber());
		
		return repository.save(admin);
	}

	@Override
	public Admin updateAdmin(AdminDTO admindto,Long adminId) {
		Admin admin=new Admin();
		admin.setAdminId(admindto.getAdminId());
		admin.setFirstName(admindto.getFirstName());
		admin.setLastName(admindto.getLastName());
		admin.setEmail(admindto.getEmail());
		admin.setPassword(admindto.getPassword());
		admin.setPhoneNumber(admindto.getPhoneNumber());
		
		return repository.save(admin);
		
	}

	@Override
	public void deleteAdmin(Long adminId) {
	
		repository.deleteById(adminId);
		
	}

	@Override
	public AdminDTO getAdmin(Long adminId) {
		Admin admin=repository.findById(adminId).orElse(new Admin());
		
		return new AdminDTO(admin.getAdminId(),admin.getFirstName(),admin.getLastName(),admin.getEmail(),admin.getPassword(),admin.getPhoneNumber());
	}

	@Override
	public List<Admin> getAllAdmin() {
		
		return repository.findAll(Sort.by("firstName"));
	}

	
}
