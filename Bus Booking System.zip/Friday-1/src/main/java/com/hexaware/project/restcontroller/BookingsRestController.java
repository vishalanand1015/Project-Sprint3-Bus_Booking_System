package com.hexaware.project.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.BookingsDTO;
import com.hexaware.project.entity.Bookings;
import com.hexaware.project.exceptions.BookingNotFoundException;
import com.hexaware.project.service.IBookings;

@RestController
@RequestMapping("/api/bookings")
public class BookingsRestController {
	@Autowired
	IBookings booking;
	
	@PostMapping("/create")
	public Bookings createBookings(@RequestBody BookingsDTO bookingsdto) {
		return  booking.createBookings(bookingsdto);
	}
	
	@PutMapping("/update/{bookingId}")
	public Bookings updatebookings(@RequestBody BookingsDTO bookingsdto,@PathVariable Long bookingId) {
		return  booking.updateBookings(bookingsdto,bookingId);
	}
	@DeleteMapping("/delete/{bookingId}")
	public void deleteBookings(@PathVariable Long bookingId)
	{
		 booking.deleteBookings(bookingId);
	
	}
	@GetMapping("/getById/{bookingId}")
	public BookingsDTO getById(@PathVariable Long bookingId)throws BookingNotFoundException{
		
		
		if(bookingId==0) {
			throw new BookingNotFoundException(HttpStatus.BAD_REQUEST,"product not found"+bookingId);
		}
		return  booking.getBookingsById(bookingId);	
		
	}
	@GetMapping("/getall")
	public List<Bookings> getAll(){
		
		return  booking.getAllBookings();	
		
	}

}
