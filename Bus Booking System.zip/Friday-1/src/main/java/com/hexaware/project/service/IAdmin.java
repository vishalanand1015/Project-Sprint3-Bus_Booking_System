package com.hexaware.project.service;

import java.util.List;

import com.hexaware.project.dto.AdminDTO;
import com.hexaware.project.entity.Admin;






public interface IAdmin {
	public Admin createAdmin(AdminDTO admindto);
	public Admin updateAdmin(AdminDTO admindto,Long bookingId);
	public void  deleteAdmin(Long adminId);
	public AdminDTO getAdmin(Long adminId);

	public List<Admin>getAllAdmin();
	

}
