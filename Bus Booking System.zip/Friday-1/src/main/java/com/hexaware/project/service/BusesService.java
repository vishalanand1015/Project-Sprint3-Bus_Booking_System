package com.hexaware.project.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.BusesDTO;
import com.hexaware.project.entity.Bookings;
import com.hexaware.project.entity.Buses;
import com.hexaware.project.repository.IBusesRepository;


@Service
public class BusesService implements IBuses {
	@Autowired
	IBusesRepository repository;

	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public Buses createBuses(BusesDTO busesdto) {
		Buses buses=new Buses();
		buses.setBusId(busesdto.getBusId());
		buses.setOperatorId(buses.getOperatorId());
		buses.setBusNumber(buses.getBusNumber());
		buses.setCapacity(buses.getCapacity());
		buses.setUserId(buses.getUserId());
		buses.setBusRoutes(buses.getBusRoutes());
		return repository.save(buses);
	}

	@Override
	public Buses updateBuses(BusesDTO busesdto,Long busId) {
		Buses buses=new Buses();
		buses.setBusId(busesdto.getBusId());
		buses.setOperatorId(buses.getOperatorId());
		buses.setBusNumber(buses.getBusNumber());
		buses.setCapacity(buses.getCapacity());
		buses.setUserId(buses.getUserId());
		buses.setBusRoutes(buses.getBusRoutes());
		return repository.save(buses);
	}

	@Override
	public void deleteBuses(Long busId) {
		
		repository.deleteById(busId);
	}

	@Override
	public BusesDTO getBusById(Long busId) {
		Buses buses=repository.findById(busId).orElse(new Buses());
		return new BusesDTO(buses.getBusId(),buses.getOperatorId(),buses.getBusNumber(),buses.getCapacity(),buses.getUserId(),buses.getBusRoutes());
	}

	@Override
	public List<Buses> getAllBuses() {
		// TODO Auto-generated method stub
		return repository.findAll(Sort.by("busId"));
	}



	@Override
	public BusesDTO getBybusId(Long busId) {
		Buses buses=repository.findById(busId).orElse(new Buses());
		return new BusesDTO(buses.getBusRoutes());
	} 

	

}
