package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.UserCustomersDTO;
import com.hexaware.project.entity.UserCustomers;
import com.hexaware.project.repository.IUserCustomersRepository;


@Service
public class UserCustomersService implements IUserCustomers {

	
	@Autowired
	IUserCustomersRepository repository;
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public UserCustomers createUser(UserCustomersDTO usercustomerdto) {
		UserCustomers usercustomer=new UserCustomers();
		usercustomer.setUserId(usercustomerdto.getUserId());
		usercustomer.setFirstName(usercustomerdto.getFirstName());
		usercustomer.setLastName(usercustomerdto.getLastName());
		usercustomer.setEmail(usercustomerdto.getEmail());
		usercustomer.setPassword(usercustomerdto.getPassword());
		usercustomer.setPhoneNumber(usercustomerdto.getPhoneNumber());
		usercustomer.setAddress(usercustomerdto.getAddress());
		usercustomer.setState(usercustomerdto.getState());
		usercustomer.setCity(usercustomerdto.getCity());
		usercustomer.setZipCode(usercustomerdto.getZipCode());
		return repository.save(usercustomer);
		
	}

	@Override
	public UserCustomers updateUser(UserCustomersDTO usercustomerdto,Long userId) {
		
		UserCustomers usercustomer=new UserCustomers();
		usercustomer.setUserId(usercustomerdto.getUserId());
		usercustomer.setFirstName(usercustomerdto.getFirstName());
		usercustomer.setLastName(usercustomerdto.getLastName());
		usercustomer.setEmail(usercustomerdto.getEmail());
		usercustomer.setPassword(usercustomerdto.getPassword());
		usercustomer.setPhoneNumber(usercustomerdto.getPhoneNumber());
		usercustomer.setAddress(usercustomerdto.getAddress());
		usercustomer.setState(usercustomerdto.getState());
		usercustomer.setCity(usercustomerdto.getCity());
		usercustomer.setZipCode(usercustomerdto.getZipCode());
		
		return repository.save(usercustomer);
		
	}

	@Override
	public void deleteUser(Long userId) {
		repository.deleteById(userId);
		
	}

	@Override
	public UserCustomersDTO getUserById(Long userId) {
		UserCustomers usercustomers=repository.findById(userId).orElse(new UserCustomers());
		return new UserCustomersDTO(usercustomers.getUserId(),usercustomers.getFirstName(),usercustomers.getLastName(),usercustomers.getEmail(),usercustomers.getPassword(),usercustomers.getPhoneNumber(),usercustomers.getAddress(),usercustomers.getCity(),usercustomers.getState(),usercustomers.getZipCode());
	}

	@Override
	public List<UserCustomers> getAllUserCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll(Sort.by("firstName"));
	}
	

}
