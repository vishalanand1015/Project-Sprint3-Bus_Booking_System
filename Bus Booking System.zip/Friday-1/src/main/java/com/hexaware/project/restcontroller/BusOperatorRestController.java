package com.hexaware.project.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.BusOperatorsDTO;
import com.hexaware.project.entity.BusOperators;
import com.hexaware.project.exceptions.BusOperatorNotFoundException;
import com.hexaware.project.service.IBusOperators;
@RestController
@RequestMapping("/api/busoperators")
public class BusOperatorRestController {
	
	@Autowired
	IBusOperators busoperators;
	
	@PostMapping("/create")
	public BusOperators createBusOperators(@RequestBody BusOperatorsDTO busoperatordto) {
		return  busoperators.createBusOperators(busoperatordto);
	}
	
	@PutMapping("/update/{operatorId}")
	public BusOperators updateBusOperators(@RequestBody BusOperatorsDTO busoperatordto,@PathVariable Long operatorId) {
		return  busoperators.updateBusOperators(busoperatordto,operatorId);
	}
	@DeleteMapping("/delete/{operatorId}")
	public void deleteBusOperators(@PathVariable Long operatorId)
	{
		busoperators.deleteBusOperators(operatorId);
	
	}
	@GetMapping("/getById/{operatorId}")
	public BusOperatorsDTO getBusOperatorsById(@PathVariable Long operatorId)throws BusOperatorNotFoundException{
		
		
		if(operatorId==0) {
			throw new BusOperatorNotFoundException(HttpStatus.BAD_REQUEST," not found"+operatorId);
		}
		return  busoperators.getBusOperatorsById(operatorId);	
		
	}
	@GetMapping("/getAll")
	public List<BusOperators> getAllBusOperators(){
		
		return  busoperators.getAllBusOperators();	
		
	}


}
