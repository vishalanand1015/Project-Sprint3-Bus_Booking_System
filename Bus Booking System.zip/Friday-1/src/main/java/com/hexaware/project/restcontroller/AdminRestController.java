package com.hexaware.project.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.project.dto.AdminDTO;
import com.hexaware.project.entity.Admin;
import com.hexaware.project.service.IAdmin;

@RestController
@RequestMapping("/api/admins")
public class AdminRestController {
	@Autowired
	IAdmin admin;
	
	@PostMapping("/create")
	public Admin createAdmin(@RequestBody AdminDTO admindto) {
		return admin.createAdmin(admindto);
	}
	@PutMapping("/update/{bookingId}")
	public Admin updateAdmin(@RequestBody AdminDTO admindto,@PathVariable Long adminId) {
		return admin.updateAdmin(admindto,adminId);
	}
	@DeleteMapping("/delete/{adminId}")
	public void deleteAdmin(@PathVariable Long adminId)
	{
		admin.deleteAdmin(adminId);
		
	}
	@GetMapping("/getById/{adminId}")
	public AdminDTO getAdmin(@PathVariable Long adminId) {
		
		return admin.getAdmin(adminId);	
		
	}
	@GetMapping("/getall")
	public List<Admin> getAllAdmin(){
		
		return admin.getAllAdmin();
	
	}
	

}
