package com.hexaware.project.service;

import java.util.List;

import com.hexaware.project.dto.TripsDTO;
import com.hexaware.project.entity.Trips;


public interface ITrips {
	public Trips createTrips(TripsDTO trips);
	public Trips updateTrips(TripsDTO trips,Long tripId);
	public void  deleteTrips(Long tripId);
	public TripsDTO getTripsById(Long tripId);
	public List<Trips>getAllTrips();
	

}
