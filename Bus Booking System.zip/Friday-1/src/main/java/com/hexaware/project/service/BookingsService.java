package com.hexaware.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hexaware.project.dto.BookingsDTO;
import com.hexaware.project.entity.Admin;
import com.hexaware.project.entity.Bookings;
import com.hexaware.project.repository.IBookingsRepository;

@Service
public class BookingsService implements IBookings {
	@Autowired
	IBookingsRepository repository;
	@Autowired
	RestTemplate restTemplate;

	@Override
	public Bookings createBookings(BookingsDTO bookingsdto) {
		Bookings booking=new Bookings();
		booking.setBookingId(bookingsdto.getBookingId());
		booking.setUserId(bookingsdto.getUserId());
		booking.setTripId(bookingsdto.getTripId());
		booking.setBookingDate(bookingsdto.getBookingDate());
		booking.setSeatNumber(bookingsdto.getSeatNumber());
		booking.setBookingStatus(bookingsdto.getBookingStatus());
		return repository.save(booking);
	}

	@Override
	public Bookings updateBookings(BookingsDTO bookingsdto,Long bookingId) {
		
		Bookings booking=new Bookings();
		booking.setBookingId(bookingsdto.getBookingId());
		booking.setUserId(bookingsdto.getUserId());
		booking.setTripId(bookingsdto.getTripId());
		booking.setBookingDate(bookingsdto.getBookingDate());
		booking.setSeatNumber(bookingsdto.getSeatNumber());
		booking.setBookingStatus(bookingsdto.getBookingStatus());
		return repository.save(booking);
		
	}

	@Override
	public void deleteBookings(Long bookingId) {
		
		repository.deleteById(bookingId);
		
	}

	@Override
	public BookingsDTO getBookingsById(Long bookingId) {
		
		Bookings booking=repository.findById(bookingId).orElse(new Bookings());
		return new BookingsDTO(booking.getBookingId(),booking.getUserId(),booking.getTripId(),booking.getBookingDate(),booking.getSeatNumber(),booking.getBookingStatus());
	}

	@Override
	public List<Bookings> getAllBookings() {
	
		return repository.findAll(Sort.by("bookingDate"));
	}

	

}
