package com.hexaware.project.dto;

public class BusOperatorsDTO {
	private Long operatorId;
	private String operatorName;
	private Long contactPhone;
	private float rating;
	private Long user_Id;

	public BusOperatorsDTO() {
		// TODO Auto-generated constructor stub
	}

	public BusOperatorsDTO(Long operatorId, String operatorName, Long contactPhone, float rating, Long user_Id) {
		super();
		this.operatorId = operatorId;
		this.operatorName = operatorName;
		this.contactPhone = contactPhone;
		this.rating = rating;
		this.user_Id = user_Id;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public Long getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(Long contactPhone) {
		this.contactPhone = contactPhone;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public Long getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(Long user_Id) {
		this.user_Id = user_Id;
	}

	@Override
	public String toString() {
		return "BusOperators [operatorId=" + operatorId + ", operatorName=" + operatorName + ", contactPhone="
				+ contactPhone + ", rating=" + rating + ", user_Id=" + user_Id + "]";
	}

	
}